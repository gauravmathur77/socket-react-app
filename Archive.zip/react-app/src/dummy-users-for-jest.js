module.exports = [
    {
        id: 1,
        name: 'Alexa'
    },
    {
        id: 2,
        name: 'Google Assistant'
    }
]