module.exports =  [
    {
        id: 1,
        name: 'Alexa'
    },
    {
        id: 2,
        name: 'Google Assistant'
    },
    {
        id: 3,
        name: 'Siri'
    },
    {
        id: 4,
        name: 'TARS'
    },
    {
        id: 5,
        name: 'CASE'
    },
    {
        id: 6,
        name: 'KIPP'
    },
    {
        id: 7,
        name: 'Jarvis'
    }
]